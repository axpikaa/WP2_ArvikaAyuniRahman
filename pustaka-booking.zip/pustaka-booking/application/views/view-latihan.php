<html>
<head>
	<title>Latihan 1</title>
</head>
<body>
Halo Bestie.. Yuk kita belajar WEB Programming..!! <br>
Nilai 1 = <?= $nilai1; ?> <br>
Nilai 2 = <?= $nilai2; ?> <br>
ini hasil dari pemmodelan dengan metode penjumlahan yaitu <?= $nilai1 . " + " . $nilai2 . " = " . $hasil; ?>

</body>
</html>