<section>
 	<h1><?php echo $judul ?></h1>
 	<h4>Nama</h4>
 	<ul type="disc">
 		<li>Nama Depan : Arvika</li>
 		<li>Nama Belakang : Ayuni</li>
 	</ul>
 	<br>
 	<h4>Alamat</h4>
 	<ul type="none">
 		<li> Jalan Mangga 2 Pasir Putih Sawangan Depok</li>
 	</ul>

 	<h4>Tempat Lahir</h4>
 	<ul type="none">
 		<li>Jakarta</li>
 	</ul>

 	<h4>Lagu Favorit</h4>
 	<ul type="square">
 		<li>Line Without A Hook</li>
 		<li>Sesuatu di Jogja</li>
 	</ul>
 </section>
